<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
        
        $productArr = Product::where('status', '=', TRUE)->get();
        return view('frontend.product.index', compact('productArr'));
    }


    public function user_logout(){
        Auth::user_logout();
        return redirect()->route('admin.admin.login')->with('success','Your logged out successfully!');
    }
}

?>