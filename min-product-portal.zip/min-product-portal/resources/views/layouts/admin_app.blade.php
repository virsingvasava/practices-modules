@include('layouts.admin_header')
@yield('content')
@include('layouts.admin_footer')
