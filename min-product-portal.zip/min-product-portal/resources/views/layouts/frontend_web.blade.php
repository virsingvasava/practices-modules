@include('layouts.frontend_header')
@yield('content')
@include('layouts.frontend_footer')