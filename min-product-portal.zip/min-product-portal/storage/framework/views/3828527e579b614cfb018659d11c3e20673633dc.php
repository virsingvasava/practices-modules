<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Categories</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">List of</li>
                    <li class="breadcrumb-item active">Categories</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <i class="bx bx-plus"></i>
                                <span class="invoice-repeat-btn">Add New</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="filter">
                             <div class="mt-3">
                                <?php if(Session::has('danger')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(Session::get('danger')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">List of <span>| Categories</span></h5>
                            <table class="table table-borderless datatable" id="category_table">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($categoryArr) && count($categoryArr) > 0): ?>
                                        <?php $__currentLoopData = $categoryArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>#<?php echo e($key + 1); ?></td>
                                                <td>
                                                    <?php if($value->cate_picture != '' && file_exists(public_path('categories_images/' . $value->cate_picture))): ?>
                                                        <img src="<?php echo e(asset('categories_images/' . $value->cate_picture)); ?>"
                                                            style="height: 70px; width: 70px;" alt="Cate Picture"
                                                            class="img-profile rounded-circle" />
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('categories_images/placeholder.svg')); ?>"
                                                            alt="" style="height: 70px; width: auto;"
                                                            class="img-profile rounded-circle" />
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(ucfirst($value->category_name)); ?></td>
                                                <td>
                                                    <div class="d-flex justify-content-between py-50">
                                                        <div class="custom-control custom-switch custom-switch-glow">
                                                            <input type="checkbox" data-id="<?php echo e($value->id); ?>" name="status" class="js-switch-cate"
                                                                <?php echo e($value->status == 1 ? 'checked' : ''); ?>>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <a href="javascript:void(0)"
                                                        class="btn icon_loader btn-sm btn-info"><i class="ri-eye-fill"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.category.edit', $value->id)); ?>"
                                                        class="btn icon_loader btn-sm btn-primary"><i
                                                            class="ri-edit-box-fill"></i>
                                                    </a>
                                                    <a href="javascript:void(0)"
                                                        class="btn btn-sm btn-danger delete_button"
                                                        data-id="<?php echo e($value->id); ?>"><i
                                                            class="ri-delete-bin-6-fill"></i></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10">No Category Found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- Popup modal for Delete start -->
    <div class="modal fade" id="categoryDeleteModel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Are You sure ?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure to Delete Category?
                </div>
                <form method="post" action="<?php echo e(route('admin.category.delete')); ?>" id="form_delete">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="page_id">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger form_submit btn_loader">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- delete modal Modal start-->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/switchery/switchery.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).on('click', '.delete_button', function() {
        $('#categoryDeleteModel').modal('show');
        $('.page_id').val($(this).attr('data-id'));
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/min-product-portal/resources/views/admin/category/index.blade.php ENDPATH**/ ?>