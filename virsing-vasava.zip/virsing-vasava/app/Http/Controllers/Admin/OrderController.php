<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Order;
use App\Models\SubCategory;
use Illuminate\Support\Str;
use File;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(){
        
        $ordersArr = Order::with('users','product')->get();
        return view('admin.order.index', compact('ordersArr'));
    }

    public function delete(Request $request)
    {
        $id = $request->id;
        Order::where('id',$id)->delete();
        return redirect()->route('admin.order.index')->with('success','Order deleted successfully');
    }
}
