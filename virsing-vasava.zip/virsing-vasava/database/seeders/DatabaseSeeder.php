<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Attendance;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $superAdmin = new User;
        $superAdmin->name = "Super Admin";
        $superAdmin->email = "admin@gmail.com";
        $superAdmin->password = Hash::make('admin@123');
        $superAdmin->role = true;
        $superAdmin->save();

        $shop1 = new User;
        $shop1->name = "Shop1";
        $shop1->shop1name = "shop1";
        $shop1->email = "shop1@devrepublic.nl";
        $shop1->password = Hash::make('devhero');
        $shop1->role = true;
        $shop1->save();

        $shop2 = new User;
        $shop2->name = "shop2";
        $shop2->shop2name = "shop2";
        $shop2->email = "shop2@devrepublic.nl";
        $shop2->password = Hash::make('admin@123');
        $shop2->role = true;
        $shop2->save();

        $user1 = new User;
        $user1->name = "User1";
        $user1->username = "user1";
        $user1->email = "user11@devrepublic.nl";
        $user1->password = Hash::make('devhero');
        $user1->role = true;
        $user1->save();

        $user2 = new User;
        $user2->name = "User2";
        $user2->username = "user2";
        $user2->email = "user2@devrepublic.nl";
        $user2->password = Hash::make('devhero');
        $user2->role = true;
        $user2->save();
    }
}
