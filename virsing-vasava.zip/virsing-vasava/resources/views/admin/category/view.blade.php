@extends('layouts.admin_app')
@section('title', 'Company - View')
@section('content')
  
@endsection
