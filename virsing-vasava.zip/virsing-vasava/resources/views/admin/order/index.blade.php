@extends('layouts.admin_app')
@section('title', 'Orders')
@section('content')
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Orders</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item">List of</li>
                    <li class="breadcrumb-item active">Orders</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="filter">
                             <div class="mt-3">
                                @if (Session::has('danger'))
                                <div class="alert alert-danger" role="alert">
                                    {{ Session::get('danger') }}
                                </div>
                                @endif
                                @if (Session::has('success'))
                                <div class="alert alert-success" role="alert">
                                    {{ Session::get('success') }}
                                </div>
                                @endif
                            </div>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">List of <span>| Orders</span></h5>
                            <table class="table table-borderless datatable" id="company_table">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Orders Number</th>
                                        <th>User Name</th>
                                        <th>Product Name</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (!empty($ordersArr) && count($ordersArr) > 0)
                                        @foreach ($ordersArr as $key => $value)
                                            <tr>
                                                <td>#{{ $key + 1 }}</td>
                                                
                                                <td>#{{ $value->id }}</td>
                                                <td>
                                                    @foreach ($value['users'] as $key => $user)
                                                        {{ ucfirst($user->name) }}
                                                    @endforeach
                                                </td>
                                                <td>
                                                    @if(!empty($value['product']))
                                                        @foreach ($value['product'] as $key => $pro)
                                                            {{ ucfirst($pro->product_name) }}
                                                        @endforeach
                                                    @else
                                                        <span>--</span>
                                                    @endif
                                                </td>

                                                <td>{{ $value->price }} </td>
                                               
                                                <td class="text-center">
                                                    <a href="javascript:void(0)"
                                                        class="btn icon_loader btn-sm btn-info"><i class="ri-eye-fill"></i>
                                                    </a>
                                                    <a href="javascript:void(0)"
                                                        class="btn btn-sm btn-danger delete_button_orders"
                                                        data-id="{{ $value->id }}"><i
                                                            class="ri-delete-bin-6-fill"></i></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="10">No Orders Found.</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- Popup modal for Delete start -->
    <div class="modal fade" id="ordersDeleteModel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Are You sure ?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure to Delete Order?
                </div>
                <form method="post" action="{{ route('admin.order.delete') }}" id="form_delete">
                    @csrf
                    <input type="hidden" name="id" class="page_id">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger form_submit btn_loader">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- delete modal Modal start-->
    <script src="{{asset('js/jquery.min.js')}}"></script>

    <script type="text/javascript">
        $(document).on('click', '.delete_button_orders', function() {
            $('#ordersDeleteModel').modal('show');
            $('.page_id').val($(this).attr('data-id'));
        })
    </script>

@endsection
