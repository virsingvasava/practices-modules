@extends('layouts.admin_app')
@section('title', 'Products - Create')
@section('content')
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Products</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                    <li class="breadcrumb-item">Create</li>
                    <li class="breadcrumb-item active"><a href="{{ route('admin.product.index') }}">Product List</a></li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="{{ route('admin.product.index') }}" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <span><i class="ri-arrow-left-circle-fill"></i></span>
                                <span class="invoice-repeat-btn">Back</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <form action="{{ route('admin.product.store') }}" method="post" id="product_create"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="card-body">
                                <h5 class="card-title">Create <span>| Product</span></h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Product Name</label>
                                            <input type="text" class="form-control" name="product_name"
                                                placeholder="Enter Product Name">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Price</label>
                                            <input type="text" class="form-control" name="price"
                                                placeholder="Enter Price">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Category</label>
                                            <select  name="category_id" size='1' class="form-select selectpicker">
                                                <option value="" selected>Select Category</option>
                                                    @foreach ($categoryArr as $value)
                                                        <option value="{{ $value->id }}">
                                                            {{ $value->category_name }}
                                                        </option>
                                                    @endforeach
                                            </select>
                                            <label id="category_id-error" class="error" for="category_id"></label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Sub Category</label>
                                            <div class="input-group">
                                                <select  name="sub_category_id" size='1' class="form-select selectpicker">
                                                    <option value="" selected>Select Sub Category</option>
                                                        @foreach ($subCateArr as $va1)
                                                            <option value="{{ $va1->id }}">
                                                                {{ $va1->sub_cate_name }}
                                                            </option>
                                                        @endforeach
                                                </select>
                                                <!-- <select class="form-select test_cate" name="sub_category_id" id="sub_category_id">
                                                </select> -->
                                                @if ($errors->has('sub_category_id'))
                                                <div class="or-error-message"><span class="text-danger">{{ $errors->first('sub_category_id') }}</span></div>
                                                @endif
                                            </div>
                                            <label id="sub_category_id-error" class="error" for="sub_category_id"></label>

                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea name="description" class="form-control {{ $errors->has('description') ? 'has-error' : '' }}" rows="4" placeholder="Description"></textarea>
                                            @error('description')
                                            <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control custom-select" name="status">
                                                <option value="">Select Status</option>
                                                <option value="1">Active</option>
                                                <option value="0">InActive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Product Picture</label> <br>
                                            <input type="file" name="image" class="productImage"
                                                onclick="productImageUpload()" accept="image/*" id="upload"
                                                hidden /><label class="image_upload_btn mb-3 mt-3" for="upload">Choose
                                                file</label><br>
                                            <img id="product_image_preview" style="display: none;" src="#"
                                                height="100" width="100" />
                                            <label id="upload-error" class="error" for="upload"></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="card-footer">
                                        <button type="submit"
                                            class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm loader_class">Submit</button>
                                        <a href="{{ route('admin.product.index') }}"
                                            class="d-none d-sm-inline-block btn btn-sm btn-danger btn_loader">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </section>
    </main>
    <script src="{{ asset('js/jquery.min.js') }}"></script>

    <script type="text/javascript">
        $(document).on('change', '.productImage', function() {
            $('#product_image_preview').hide();
            readURL(this);
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#product_image_preview').attr('src', e.target.result);
                    $('#product_image_preview').show();
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function itemImageUpload() {
            document.getElementById("productImage").click();
        }

        $(document).ready(function() {
        // $('select[name="sub_category_id"]').append('<option value="">Select Sub Category</option>');
        // $('select[name="sub_category_id"]').niceSelect('update');
        $('select[name="category_id"]').on('change', function() {
            var categoryID = $(this).val();
            var token = "{{csrf_token()}}";
            if (categoryID) {
                $.ajax({
                    url: "{{ route('admin.product.get_sub_category') }}",
                    type: "post",
                    data: {
                      category_id: categoryID,
                      _token: token
                    },
                    success: function(data) {
                        $('select[name="sub_category_id"]').empty();
                        $('select[name="sub_category_id"]').append(
                            '<option value="">Select Sub Category</option>');
                        $.each(data, function(key, value) {
                            $('select[name="sub_category_id"]').append('<option value="' +
                                key + '">' + value + '</option>');
                        });
                        $('select[name="sub_category_id"]').niceSelect('update');
                    }
                });
            } else {
                $('select[name="subcat_id"]').empty();
            }
        });
    });
    </script>
@endsection
