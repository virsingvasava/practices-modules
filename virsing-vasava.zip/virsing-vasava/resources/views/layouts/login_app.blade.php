@include('layouts.login_header')
@yield('content')
@include('layouts.login_footer')

