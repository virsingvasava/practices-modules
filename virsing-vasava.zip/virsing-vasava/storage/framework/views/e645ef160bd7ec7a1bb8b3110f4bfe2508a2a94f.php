<?php $__env->startSection('title', 'Company - View'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Companies</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">View</li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.company.index')); ?>">Companies List</a></li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="<?php echo e(route('admin.company.index')); ?>" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <span><i class="ri-arrow-left-circle-fill"></i></span>
                                <span class="invoice-repeat-btn">Back</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body">
                            <h5 class="card-title">View <span>| Company Details</span></h5>
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th>Name</th>
                                        <td><?php echo e($company_view->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo e($company_view->email); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Website</th>
                                        <td><?php echo e($company_view->website); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Logo</th>
                                        <td>
                                            <?php if($company_view->logo_picture != '' && file_exists(public_path('company_logo/' . $company_view->logo_picture))): ?>
                                                <img src="<?php echo e(asset('company_logo/' . $company_view->logo_picture)); ?>"
                                                    style="height: 80px; width: 80px;" alt="Logo Picture"
                                                    class="img-circle elevation-2" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('company_logo/avatar.jpg')); ?>" alt="Logo Picture"
                                                    style="height: 80px; width: auto;" class="img-circle elevation-2" />
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php if($company_view->status == 1): ?>
                                                <span style="color:green;">Active</span>
                                            <?php else: ?>
                                                <span style="color:red;">InActive</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/virsing-vasava/resources/views/admin/product/view.blade.php ENDPATH**/ ?>