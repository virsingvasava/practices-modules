<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item ">
            <a class="nav-link <?php echo e(request()->is('admin/dashboard*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-heading">Master</li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/product*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.product.index')); ?>">
                <i class="ri-list-check"></i>
                <span>Products</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/category*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.category.index')); ?>">
                <i class="ri-list-check"></i>
                <span>Categories</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/sub-category*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.sub_category.index')); ?>">
                <i class="ri-list-check"></i>
                <span>Sub Categories</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/order*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.order.index')); ?>">
                <i class="ri-list-check"></i>
                <span>Orders</span>
            </a>
        </li>

        <li class="nav-heading">Settings</li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                <i class="ri-list-settings-fill"></i><span>Admin Settings</span>
            </a>
            <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a class="nav-link <?php echo e(request()->is('admin/profile*') ? '' : 'collapsed'); ?>"
                        href="<?php echo e(route('admin.profile.index')); ?>">
                        <i class="bi bi-person"></i>
                        <span>Profile</span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</aside>
<?php /**PATH /opt/lampp/htdocs/virsing-vasava/resources/views/layouts/admin_sidebar.blade.php ENDPATH**/ ?>