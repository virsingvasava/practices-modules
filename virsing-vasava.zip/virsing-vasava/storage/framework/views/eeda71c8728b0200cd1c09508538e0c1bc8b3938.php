<?php $__env->startSection('title', 'Employees Attendances'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Employees Attendances Info.</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">List of</li>
                    <li class="breadcrumb-item active">Employees Attendances</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
              <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="javascript:void(0)" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <i class="bx bx-plus"></i>
                                <span class="invoice-repeat-btn">Import Data</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-2 mt-3 mb-4">
                    <p style="color:#000; background-color:red;text-align:center;"> Not completed 8 hours  </p>
                    <p style="color:#000; background-color:yellow;text-align:center;"> Not completed 4 hours  </p>
                    <p style="color:#000; background-color:#0d6efd;text-align:center;"> Taken more then 1 hour break  </p>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="filter" style="display:none">
                            <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                <li class="dropdown-header text-start">
                                    <h6>Filter</h6>
                                </li>
                                <li><a class="dropdown-item" href="#">Today</a></li>
                                <li><a class="dropdown-item" href="#">This Month</a></li>
                                <li><a class="dropdown-item" href="#">This Year</a></li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">List of <span>| Users</span></h5>
                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Emp_code</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Date</th>
                                        <th>In_Time</th>
                                        <th>Out_Time</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($attendanceArr) && count($attendanceArr) > 0): ?>
                                        <?php $__currentLoopData = $attendanceArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>#<?php echo e($key + 1); ?></td>
                                                <td><?php echo e(ucfirst($value->emp_code)); ?></td>
                                                <td><?php echo e(ucfirst($value->name)); ?></td>
                                                <td><?php echo e($value->email); ?></td>
                                                <td><?php echo e($value->date); ?></td>
                                                <td><?php echo e($value->in_time); ?></td>
                                                <td><?php echo e($value->out_time); ?></td>
                                                
                                                <td class="text-center">
                                                        <?php
                                                            
                                                            $start_t = new DateTime($value->in_time);
                                                            $end_t = new DateTime($value->out_time);
                                                            $difference = $start_t->diff($end_t)->format('%H:%I:%S');
                                    
                                                            $lunch_1_hours = date('H:i:s', strtotime($difference. ' -1 hours'));
                                                            $red_8_hours =  date('H:i:s', strtotime($difference. ' -1 hours'));
                                                            $yellow_4_hours = date('H:i:s', strtotime($difference. ' -1 hours'));

                                                            $blue_1_hours = "1";

                                                            /*
                                                            open = 9:00:00
                                                            end = 18:00:00
                                                            check_in = 08:55:00
                                                            check_out = 17:50:00
                                                            late = open - check_in = 00:03:00
                                                            early = end - check_out = 00:10::
                                                            */

                                                        ?>

                                                        <!-- <?php if($lunch_1_hours == 1): ?>
                                                           <p style="color:#000; background-color:gray;"><?php echo e($lunch_1_hours); ?></p>
                                                        <?php endif; ?> -->

                                                        <?php if($red_8_hours == 8): ?>
                                                            <a href="#" class="btn icon_loader btn-sm btn-info" style="color:red;">Completed 8 hours</a>
                                                        <?php else: ?>
                                                          <p style="color:#000; background-color:red;"><?php echo e($red_8_hours); ?></p>
                                                        <?php endif; ?>

                                                        <?php if($yellow_4_hours == 4): ?>
                                                            <a href="#" class="btn icon_loader btn-sm btn-info" style="color:#000; background-color:yellow;">completed 4 hours </a>
                                                        <?php else: ?>
                                                            <p style="color:#000; background-color:yellow;"><?php echo e($yellow_4_hours); ?></p>
                                                        <?php endif; ?>

                                                        <!-- <?php if($blue_1_hours != 1): ?>
                                                            <a href="#" class="btn icon_loader btn-sm btn-info" style="color:#000; background-color:yellow;">Not take more then 1 hours</a>
                                                        <?php else: ?>
                                                            <p style="color:#000; background-color:blue;"><?php echo e($blue_1_hours); ?></p>
                                                        <?php endif; ?> -->
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10">No Employee Found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
   
<style>
    tr th {
        text-transform: uppercase;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/virsing-vasava/resources/views/admin/attendance/index.blade.php ENDPATH**/ ?>